import React from 'react';
import GlowMatchApp from './GlowMatchApp';

function App() {
  return <GlowMatchApp />;
}

export default App;